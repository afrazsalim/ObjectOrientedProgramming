package jumpingalien.part3.Expressions;

public class getXtest {
/*
	@Test
	public void test() {
		IFacadePart2 facade = new Facade();
		Expression e = new objectTypesTests(facade.createMazub(8, 499, spriteArrayForSize(10, 3)));
		isMazub t = new isMazub(e,new SourceLocation(5,5));
		System.out.println(t.getValueOfConstant());
	}
*/
}
