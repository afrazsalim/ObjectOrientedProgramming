package jumpingalien.part3.Expressions;

public class objectTypesTests {
/*
	private gameObjectType gameObjectType;

	public objectTypesTests(Mazub M) {
       this.setValue(new gameObjectType(M));
	}

	private void setValue(gameObjectType gameObjectType) {
           		 this.gameObjectType = gameObjectType;
	}

	
	@Override
	public String toString() {
		return "this.gameObjectType";
	}



	@Override
	public Type getValueOfConstant(Program program) {
 		return this.gameObjectType;
	}

	@Override
	public Expression getValue(Program program) {
		return this;
	}
	*/

}
