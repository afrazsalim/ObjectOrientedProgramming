package jumpingalien.part3.Expressions;

public class AndExpressionTest {
/*
	@Test
	public void test() {
        Expression e = new TrueLiteral(new SourceLocation(1,1));
        Expression e2 = new TrueLiteral(new SourceLocation(1,1));
        AndExpression exp = new AndExpression(e,e2,new SourceLocation(1,1));
        assertEquals(e.getValueOfConstant().getValueOfConstant(),exp.getLeftOperand().getValueOfConstant().getValueOfConstant());
        assertEquals(e2.getValueOfConstant().getValueOfConstant(),exp.getRightOperand().getValueOfConstant().getValueOfConstant());
	}
*/
}
