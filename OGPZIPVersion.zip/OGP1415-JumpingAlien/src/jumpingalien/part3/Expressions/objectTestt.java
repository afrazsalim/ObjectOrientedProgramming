package jumpingalien.part3.Expressions;

public class objectTestt {
/*
	@Test
	public void test() {
	IFacadePart2 facade = new Facade();
	 Mazub alien = facade.createMazub(0, 499, spriteArrayForSize(3, 3));
     Expression e  = new objectTypesTests(alien);
     Expression height = new getheight(e,new SourceLocation(1,1));
     assertEquals(3.0,height.evaluate(null).getValueOfConstant());
	}
	
	@Test
	public void test_getHitPoints(){
		 IFacadePart2 facade = new Facade();
		 Mazub alien = facade.createMazub(0, 499, spriteArrayForSize(3, 3));
	     Expression e  = new objectTypesTests(alien);
	     Expression hp = new getHitPoints(e,new SourceLocation(1,1));
	     assertEquals(100.0,hp.evaluate(null).getValueOfConstant());
	     System.out.println(hp.evaluate(null));
	}

	@Test
	public void test_isMazub(){
		 IFacadePart2 facade = new Facade();
		 Mazub alien = facade.createMazub(0, 499, spriteArrayForSize(3, 3));
	     Expression e  = new objectTypesTests(alien);
	     Expression hp = new isMazub(e,new SourceLocation(1,1));
         assertTrue((boolean)hp.evaluate(null).getValueOfConstant());
         System.out.println(hp);
	}
	
	
	*/
}
