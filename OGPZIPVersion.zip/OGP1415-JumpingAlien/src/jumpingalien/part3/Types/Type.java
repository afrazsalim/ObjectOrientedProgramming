package jumpingalien.part3.Types;

public class Type {

}
