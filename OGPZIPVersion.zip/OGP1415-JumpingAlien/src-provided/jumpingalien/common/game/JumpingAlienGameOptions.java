package jumpingalien.common.game;

import ogp.framework.game.GameOptions;

public interface JumpingAlienGameOptions extends GameOptions {

	public double getTimescale();
	public void setTimescale(double value);
}
