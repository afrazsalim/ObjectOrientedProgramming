package jumpingalien.common.game;

import java.util.Optional;

public interface WorldInfoProvider {

	public Optional<int[]> getWorldSize();
}
