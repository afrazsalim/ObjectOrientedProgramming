package ogp.framework.messages;

public enum MessageType {

	DEBUG,
	INFO,
	WARNING,
	ERROR
	
}
