package ogp.framework.gui;

public interface GUIOptions {

	public double getTargetFPS();
	
	public boolean isFullScreenEnabled();
}
