package ogp.framework.game;

public interface GameOptions {

}
